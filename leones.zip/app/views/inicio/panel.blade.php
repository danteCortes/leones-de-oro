@extends('plantilla')

@section('titulo')
Inicio | Panel
@stop

@section('contenido')

@stop