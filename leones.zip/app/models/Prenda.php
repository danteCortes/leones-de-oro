<?php

class Prenda extends Eloquent{

	protected $table = 'prendas';

	public $timestamps = false;
}