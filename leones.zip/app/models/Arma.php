<?php

class Arma extends Eloquent{

	protected $table = 'armas';

	public $timestamps = false;
}