<?php

class Cargo extends Eloquent{

	public $timestamps = false;
}